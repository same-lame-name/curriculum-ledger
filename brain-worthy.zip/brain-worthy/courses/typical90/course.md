# Course: Typical90 — Ninety Problems, One Idea at a Time
state: active
source: courses/typical90/sources/
scope: All 90 cards, guided discovery, ceiling Codeforces ≤ 2000 (`stretch` cards droppable)

## Where the student stands
- **Solid — do not re-derive:** cost arithmetic; prefix sums; recursion call-counting; 64-bit widening;
  bitmasks; signed `%`; graph-as-data; the two-pointer safety proof; log base 2; convexity-as-a-count;
  exchange arguments (048); subset DP — `(mask, last)` reached before writing any code (032). He finds a
  card's intended insight unaided often enough that **pre-teaching the idea is the main risk**: open cold.
- **Growing edge:** names a sufficient condition and calls it necessary — *closed* for plain bounds (002),
  still live where a *necessary-looking* test must be argued sufficient (**025**). Concludes about the sum
  when the question was about a specific set (048). Inspects small cases instead of partitioning.
- **Unmeasured:** failure under a fixed deadline (4 Arena cards, all first-attempt, 8–11 min on a count-up
  stopwatch); **debugging his own WA — 0 WA across all four**; a problem with no known technique.
- **Teaching levers:**
  - Ask size/headroom questions **on their own line** — stapled to "write it", he answers the code and
    drops the arithmetic.
  - Hand him a generalised tool **cold**; the transfer happens by itself (064 → 028 same sitting).
  - **Ask what he will literally write before arguing against it.** He has beaten my assertion five times.
    Stop supplying his implementation for him.
- **Chapter 7 (050 008 042 046 069) is re-aimed:** the `(mask, last)` state is already his — do not
  re-derive it. Spend the board on which *dimension* belongs in the mask. Fragility he should keep: his
  virtual base row `f(0, x) = 0` is sound only because `X < Y` forbids self-rumours, so `ok[nxt][nxt]` is
  never falsified; an `X == Y` rumour would collapse it.

## Plan
- [x] 1. Treat N as a cost; find the sentence that makes the problem finite — **COMPLETE 8/8 AC** (024 022 027 033 055 067 038 020)
- [x] 2. A contiguous range is the difference of two stored numbers — **COMPLETE 7/7 AC** (004 010 084 064 028 081 076)
- [x] 3. Sort first, then the local choice stops depending on the rest — **COMPLETE 4/4 AC** (014 007 070 048)
- [>] 4. Read the small constraint, then delete a dimension from the brute force — **3/6** (002 ✓ · 032 ✓ · 016 ✓ · 085 023 025) — *plus 032's subset-DP variant (N ≤ 18) AC*
- [ ] 5. The odd constraint is the door; bits and subsets are independent (063 086 080 045)
- [ ] 6. When the shape is too weird for loops, that is a reason to recurse (072 088)
- [ ] 7. Give the state a name — what the future can still tell apart (050 008 042 046 069)
- [ ] 8. Choose or skip, then walk the table backwards to print the plan (056 011 051)
- [ ] 9. An interval DP asks what happens last, and fills by length (019)
- [ ] 10. Never list the objects; sum over structure (052 082 066 015)
- [ ] 11. See that it is a graph before asking which algorithm (078 012 068 021 058 054 071)
- [ ] 12. The vertex is not always the state (013 043)
- [ ] 13. In a tree the path is unique, so every question is about subtrees (003 026 039 073)
- [ ] 14. Turn the answer into a yes/no question and find the threshold (001 006 060 087)
- [ ] 15. The left end never needs to move backwards (034 089)
- [ ] 16. Remember only what actually changes (061 044 029 037)
- [ ] 17. Find the quantity the operations cannot change (079 074 062 049 057)
- [ ] 18. Independent games add by XOR (031)
- [ ] 19. Factor structure is sparse, and sparsity is the bound (030 075 065)
- [ ] 20. Change coordinates until the awkward quantity is simple (018 036 041)
- [ ] 21. Above the ceiling: meet the tools, park the expensive ones (009 017 059 047 053 035 083 077 040 005 090)

## On the board right now
- Working on: **Chapter 4, 3/6. Sit 9 complete.** `002 032 016` + the `N ≤ 18` subset-DP variant — all first
  attempt, 0 WA, 0 hints, all grader-accepted. No code in flight.
- Next move: **Sit 10** = `085` → `023` → `025` (025 alone if it runs long). Open `085`
  (https://atcoder.jp/contests/typical90/tasks/typical90_cg) via Pure Cold Launch.
  **Hold back for 085:** every one of a, b, c divides `K`; `K ≤ 10^12` has at most ~6700 divisors; the budget
  comes from `τ(K)`, not from `N`; the `a ≤ b ≤ c` filter's cube case (`a = b = c`), which the source dodges.
- **Mode for 085: `checkpoint`, not `guided`** — rated, blind metadata, hints locked. Rationale: 0 WA across
  four Arena cards means we hold no sample of him recovering from a wrong answer, and a cold rated card is
  the cheapest way to generate one. If he objects, `guided` is fine; the gap just stays open.

## Habits & tangents to remember

### Watch out for (active)
- **`N` and every limit are read off the card, never recalled.** (048, twice — and me, twice on 2026-11-06.)
- **Answer the step you are on, not the one next to it.** Ask *"what could go wrong right HERE?"* before
  calling the last brick laid (048).
- **Headroom and sentinels: state the ANSWER's ceiling on its own line, before code.** One term ≤ `2·10^9`
  fits `int`; the sum over `10^5` does not (070). And `INF` must clear that ceiling *deliberately* —
  `1e9+7` has been right by exactly 7 twice (007, 016), luck both times, not a stated bound.
- **A boundary is a case to answer, not to dodge** — 064 `d[0] += V`; 028 `result[-1]++`; 081 a guard that
  refused a real window and printed the sentinel. A guard that skips work silently shrinks the candidate
  set. Two honest repairs: *handle* it, or *prove* it covered and write that argument in the comment.

### Transferable — with the card where it fires next
- **Prove an obligation can never arise, then delete the guard.** 048 (`A_i/2 < B_i` vanished); again on
  016 (no `-1` branch, licensed by the promise). Order matters: prove, then remove. Never the reverse.
- **Pairing the terms bounds tighter than bounding them one at a time** (048: `N·10^9`, not `4·10^14`).
  → 037, 061.
- **When a greedy walks until it stops improving, ask what is MONOTONE** — usually a *count* (070).
  → 034, 089, Ch 14.
- **`Δ(a)` prices the step OUT of `a`**, so `Δ = 0` is sufficient, not necessary, and the minimisers form
  an *interval*. → Ch 14.
- **Bound by partitioning, never by comparing patterns** (033); `C(N,5)` not `N^5` (055); divide before
  multiplying to test a bound (038); compare exact integers (020).

### Terse checklists
- **Types:** `1e18` is a `double` — write `1000000000000000000LL`. Sum `N·A[i]` *before* choosing int vs
  `long long`. `abs` needs a `long long` argument to pick that overload. `int A[2000][2000]` in `main` is
  8 MB of stack ⇒ segfault. `-Wconversion` catches what `-Wall -Wextra` allow.
- **`next_permutation`:** ascending on entry, or you silently start mid-way; it returns `false` at the
  descending order, so the loop is `do { … } while (…)` — a `while (…)` skips the first order.
- **A sample can be invariant under the bug you fear.** 032's samples all pass with a transposed `A`.
  Settle index orientation with an asymmetric constrained case, never a symmetric one.
- **Prefix sums:** 1-index with `S[0] = 0`; always test `L = 1`.
- **Proof hygiene:** delete a statement's permission and see whether the proof survives. Sample contradicts
  statement ⇒ trust the sample, check the Japanese (033).

### Standing rules (how I work)
- **AC ≠ correct** (081 AC'd while printing `0` on every `K = 5000` input). An independent oracle is
  independent of *my* reasoning, not infallible — verify the findings that smell.
- Implementation runs in the Arena (`arena_run`); grading goes through `problem-grader` on the returned
  inline code, **not** my own bash harness.
- **The close is the verdict and the tick — nothing else.** No manufactured "what the finished code
  reveals". After an AC on an already-derived card: verdict, tick, ask what's next.
- **The staged difficulty is my number, stated honestly and out loud**, anchored to a same-shape problem —
  never to his rating, never to what makes the delta feel right. `problem-recommender`'s catalog holds none
  of these cards, so it cannot rate them; and I don't dig in `.pi/agents/catalog` myself to fake a second
  opinion.
- **`-D_GLIBCXX_DEBUG` changes asymptotics, not just constants** — on 007 it rebinds `lower_bound`:
  `Q log N` → `Q·N` = `10^10`, 175 s instead of 0.02 s. Re-time at plain `-O2`.
- `-DLOCAL` is never defined on any judge in his setup; the `freopen` block is inert. **Closed.**
- **No archive directory in the course folder, ever.** A ✓ in Plan plus `arena_ledger` are the record; he
  deletes old files on purpose.
- He refuses defensive `cin`-failure checks as CP-unnecessary. **Conceded and closed — do not reopen.**

## Session log
- 2026-10-24 → sessions/2026-10-24.md
- 2026-10-25 → sessions/2026-10-25.md
- 2026-10-30 → sessions/2026-10-30.md
- 2026-11-01 → sessions/2026-11-01.md
- 2026-11-02 → sessions/2026-11-02.md
- 2026-11-06 → sessions/2026-11-06.md
