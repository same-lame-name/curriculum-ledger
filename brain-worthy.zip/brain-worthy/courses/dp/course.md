# Course: Dynamic Programming (article + 66 curated problems)
state: active
source: courses/dp/sources/ (article.md = TopCoder DP treatise Parts 1–3; problems/ = 66 cards; solutions/ = 57 verified C++)
scope: AtCoder DPC A–Z, TDPC A–T, NDPC A–T. Done = cold-solve CF ≤ 2000 DP problems. Above ~2200 = stretch vault, opened only on appetite.

## Where the student stands
- **Solid on:** the **coordinate rotation**, unprompted and in one breath — "the values are small now, so ask for the least weight at each exact value" (E, first attempt AC 22:26, zero hints). Exactly-semantics written in code, not just discussed: `dp[0][0]=0`, rest `INF`, read-out by scan. Deriving the state from the future's question, and *inventing* boundary states rather than special-casing them (virtual day 0 = `A^0 = I` = a grid's border row). Order as a **release schedule**, not a sort — which released vertex goes next is free. Domination and natural death as separate ideas. Invariants that replace branches. "Prove the domain, not the code." Never materialising a range — endpoints and a difference array instead. Pull ↔ push as a free rewrite. On knapsack they deleted the chosen-set axis with a scan order and put the take-branch on layer `i-1` unprompted.
- **Growing edge:** **recognition, not derivation** — their own words, *"reasoning through an already visited forest."* The cure is breaking the problem slightly and asking which sentence of the writeup moves; more explanation does nothing. Also: "what must I keep alive" lags "what must I prove" — proved row `i` reads only row `i-1` twice, then allocated the full table both times. Expectation DP is at zero footing (Ch. 7, board-built).
- **Watch out for:** a new instance of the same shape, on the last problem: a byte-diff against a local expected file (missing trailing `\n`) was read as *"the judge rejected me"*. Same family as E's comment — a true observation bound to the wrong cause.
- **Watch out for (older):** justifying a line with a true but *irrelevant* reason. E's guard carried the comment `// only if current state is reachable` — reachability is exactly what the `INF` arithmetic already does alone (grader: zero drift); the guard's real job is bounding the index `value+v`, and removing it is a heap-buffer-overflow, not a wrong answer. The line was right, the comment was the bug. Also: objective drift on a fast read (Frog 1 read as "count ways"). Sentinel arithmetic — `+1e15` is unattainable yet wins a `max` read-out, and any `+` beside a sentinel is an escape: `-INF + 60` sat in a real cell. Template `INF` is now `1e12+7`, so width is dead; the ordering hazard is not.

## Plan
- [x] 1. A state is a promise about the future (1D scans) — A ✓ B ✓ C ✓
- [x] 2. Overlapping work on grids and DAGs — H ✓ G ✓ NDPC B ✓ NDPC H ✓
- [x] 3. Carrying a budget: knapsack and its rotations — D ✓, E ✓, TDPC A ✓
- [>] 4. Two sequences at once — F, NDPC C
- [ ] 5. Killing an inner loop: prefix sums, windows, ranks — M, T, TDPC F, TDPC L
- [ ] 6. Intervals: the last split is the decision — N, L, TDPC B, TDPC I
- [ ] 7. Adversaries and dice: games, probabilities, expectations — K, I, TDPC C, D, J
- [ ] 8. Subsets as states — O, U, TDPC J
- [ ] 9. Trees: the answer depends on one boundary — P, V
- [ ] 10. Layers, vectors, huge K — R, NDPC E, TDPC M
- [ ] 11. Sort first: exchange arguments and sweeps — Q, X, Y, TDPC K
- [ ] 12. Digits and carries — S, TDPC E, NDPC D
- [ ] 13. Profiles: one layer at a time — NDPC A
- [ ] Vault (appetite only, not a path): DPC Z, W; TDPC P/N/O/G/H/Q/R/S/T; NDPC F/G/I/J/K/L/M/O/P/Q/R/S/T — 24 problems, all ≥2100. Also where interleaved reps may be drawn from.
- [ ] Interleaved reps — next checkpoint **after Ch 4**, 2 reps, mechanism never named. 0 / ~70 done. Protocol: `curriculum.md` § Practice Tracks.

## On the board right now
- Working on: **nothing — paused at the end of Ch. 3.** Nothing is mid-derivation; no problem is open.
- Ch. 3 closed: **D ✓ E ✓ TDPC A ✓**. TDPC A went AC three times on the same file shape — 11:04 bool row (600/600 oracle-checked), then 06:24 as a first-ever `bitset` (400/400), then a 1:06 harness run. All `guided`/unrated; the only rating-bearing entry in the course so far is still `dpc_e` (drill, 1500, +14 → 1214).
- Next move: **Ch. 4 — LCS (DPC F)**, https://atcoder.jp/contests/dp/tasks/dp_f, `sources/problems/dpc-f-lcs.md`. Opened cold at the board once already and the student declined to continue there — reopen only when they ask. The new mechanic is **reconstruction** (the answer is the subsequence, not its length). Then NDPC C, then the first `checkpoint` pair (2 interleaved reps, blind metadata, locked hints) — that is where rating is *supposed* to move.

## Habits & tangents to remember
- **Working preferences:** they solve first, we discuss after. Never open the next problem until they ask for it — "resume" means resume at the pause point, not advance the plan. `purpose` must *describe* how a problem was met; never offer a rated run in the same breath as a rating discussion. Statement, constraints and samples only when a problem goes up — no framing, no hints, no unrequested nudging, and never pre-empt the next one.
- **Teacher rules:** every number on the board is scripted before it is shown, including mine. State an invariant's *strength* only after checking whether it could ever be false. Every AC gets verified against an independent oracle or brute force before it is ticked. "I don't know" means shrink the step, never re-ask the stem louder.
- **Watch out for:** conflating "an order is required" with "a *particular* order is required" — a heap was proposed for Kahn's. Re-test when ordering returns in Ch. 5 and Ch. 8.
- **Parked for later:** expectation DP from scratch (Ch. 7); "where greedy fails vs DP" as a running aside.

## Session log
- 2026-10-24 → sessions/2026-10-24.md
- 2026-10-25 → sessions/2026-10-25.md
- 2026-10-31 → sessions/2026-10-31.md
- 2026-11-02 → sessions/2026-11-02.md
- 2026-11-04 → sessions/2026-11-04.md 
- 2026-11-05 → sessions/2026-11-05.md 
